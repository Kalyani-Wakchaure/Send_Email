import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email(subject, body, to_email):
    from_email = "pgdaikalyani.neubrain@gmail.com"
    password = "xapg czmh hmab kmyf"
    # Use your App Password if 2-Step Verification is enabled

    # Create the email message
    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    try:
        # Set up the SMTP server
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Secure the connection
        server.login(from_email, password)
        
        # Send the email
        server.sendmail(from_email, to_email, msg.as_string())
        print(f'Email sent to {to_email}')
        
        # Quit the SMTP server
        server.quit()
    except Exception as e:
        print(f'Failed to send email. Error: {e}')

if __name__ == "__main__":
    subject = "Test Email from Python"
    body = "This is a test email sent from a Python script."
    to_email = "kalyaniwakchaure21@gmail.com"
    send_email(subject, body, to_email)
